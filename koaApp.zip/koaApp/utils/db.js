const mysql = require('mysql');
const pool = mysql.createPool({
  host: "127.0.0.1",
  user: "root",
  password: "root",
  database: "test"
});
const query = (sql, values) => {
  return new Promise((res, rej) => {
    pool.getConnection((err, conn) => {
      if(err)
        rej(err);
      else
        conn.query(sql, values, (err, results)=> {
          if(err)
            rej(err);
          res(results);
          conn.release();
        });
    });
  });
}
module.exports = {
  query
};