const router = require('koa-router')()
const mysql = require('mysql');
const conn = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "root",
  database: "test"
});
//conn.connect();
router.get('/list', async (ctx, next) => {
  await new Promise((res, rej) => {
    conn.query("select * from users", (err, result) => {
    res(result);
    if(err) {
      rej(err);
    }
  });
  }).then((v) => {
    ctx.body = v;
  }).catch(err => {
    console.log('[SELECT ERROR] - ', err.message);
  });
});
/*router.get('/', async (ctx, next) => {
  await ctx.render('index', {
    title: 'Hello Koa 2!'
  })
})

router.get('/string', async (ctx, next) => {
  ctx.body = 'koa2 string'
})

router.get('/json', async (ctx, next) => {
  ctx.body = {
    title: 'koa2 json'
  }
})*/

module.exports = router
