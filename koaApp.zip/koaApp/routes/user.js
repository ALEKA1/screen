const router = require('koa-router')()
const db = require('../utils/db');
//const token = require('../utils/token');
router.get('/user/list', async (ctx, next) => {
  let param = ctx.request.query;
  let offset = parseInt(param.offset, 10) || 0;
  let limit = parseInt(param.limit, 10) || 10;
  let datas = await db.query("select * from pre_t__user limit ?,?", [offset, limit]);
  let total = await db.query("select id from pre_t__user");
  ctx.body = {
    datas,
    total: total.length,
    code: 0
  };
});
router.post('/user/login', async (ctx, next) => {
  let param = ctx.request.body;
  let username = param.username;
  let password = param.password;
  //let data = await db.query("select * from pre_t__user where username=? and id=?", [username, id]);
  let data = await db.query("select * from pre_t__user where ? and ?", [{username}, {password}]);
  if(data && data.length) {
    ctx.body = {
      data: data[0],
      //token: token(data.username, '10s'),
      msg: '登录成功',
      code: 0
    };
  } else {
    ctx.body = {
      data: {},
      msg: '用户名或密码错误',
      code: -1
    };  
  }
});
router.get('/user/get', async (ctx, next) => {
  console.log(1234);
  let query = ctx.request.query;
  let id = query.id;
  //let data = await db.query("select * from pre_t__user where username=? and id=?", [username, id]);
  let data = await db.query("select * from pre_t__user where ?", [{id}]);
  ctx.body = {
    data,
    code: 0
  };
});
router.get('/user/test', async (ctx, next) => {
  /*ctx.body = '测试页面';
  ctx.redirect("/string");
  ctx.body = '测试页面';*/
  ctx.status = 301;
  ctx.redirect('/string');
  ctx.body = 'Redirecting to shopping cart';
});
module.exports = router